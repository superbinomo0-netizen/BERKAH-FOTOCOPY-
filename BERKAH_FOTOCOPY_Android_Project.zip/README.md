# BERKAH FOTOCOPY — proyek Android

Aplikasi kasir Android sederhana untuk BERKAH FOTOCOPY.

## Fitur
- Transaksi dan keranjang belanja
- Pembayaran Cash dan Transfer
- Stok otomatis berkurang setelah transaksi
- Tambah/hapus produk dan penyesuaian stok
- Laporan harian berdasarkan tanggal perangkat
- Bagikan struk/laporan melalui menu berbagi Android
- Cetak melalui layanan cetak Android
- Data disimpan lokal di perangkat menggunakan localStorage WebView

## Cara membuat APK
1. Instal Android Studio versi terbaru di komputer.
2. Ekstrak ZIP proyek ini.
3. Android Studio → Open → pilih folder `BerkahFotocopy`.
4. Tunggu Gradle Sync dan izinkan Android Studio mengunduh Android SDK/Gradle yang diperlukan.
5. Pilih Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan penting
- Proyek ini adalah source project Android; APK belum dikompilasi di lingkungan ini karena Android SDK dan Gradle tidak tersedia.
- Data transaksi tersimpan pada perangkat yang menjalankan aplikasi. Hapus data aplikasi atau uninstall dapat menghapus data; lakukan backup sebelum reset perangkat.
- Cetak membutuhkan printer/layanan cetak yang didukung Android. Printer Bluetooth tertentu mungkin memerlukan aplikasi/driver vendor.
- Untuk penggunaan operasional, uji alur transaksi, cetak, dan berbagi di perangkat Android serta lakukan backup rutin.
