plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.berkahfotocopy.kasir"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.berkahfotocopy.kasir"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
